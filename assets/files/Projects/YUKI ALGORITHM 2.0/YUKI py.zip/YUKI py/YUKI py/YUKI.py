# YUKI Alogrithm by BRAHIM BENAISSA
# REFERENCE PAPER: https://doi.org/10.1016/j.jocs.2021.101451
# YUKI Algorithm and POD-RBF for Elastostatic and dynamic crack identification

import matplotlib.pyplot as plt
import numpy as np

EXP = 0.5

Number_of_Runs = 10
populationsize = 20
Max_iterations = 500

lb = -500
ub = 500
Dim = 2


# Lists to store the progress data
fitness_progress = []
center_progress = []


def fobj(x): # schwefel fcn
    d = len(x)
    return 418.9829 * d - np.sum(x * np.sin(np.sqrt(np.abs(x))))


for Run in range(Number_of_Runs):
    print('%%%%%%%%%%%%%%%%%%%%%%%%%%')
    print(f'     %%%% RUN: {Run+1} %%%%%')
    print('%%%%%%%%%%%%%%%%%%%%%%%%%%')

    # Initialization
    Pos = np.random.rand(Dim, populationsize) * (ub - lb) + lb
    Fit = np.apply_along_axis(fobj, 0, Pos)

    # initial values
    Best_Poses = Pos.copy()
    Best_Fits = Fit.copy()
    MeanBest = np.mean(Best_Poses, axis=1)
    ind = np.argmin(Fit)
    Optimum_Fit = Fit[ind]
    Center = Pos[:, ind]
    Dist_MeanBest = np.abs(Center - MeanBest)

    # Lists to store the progress within each run
    run_fitness_progress = []
    run_center_progress = []

    # Itirative search START HERE
    for It in range(Max_iterations):
        # Calculate the local search boundaries
        Local_lb = Center - Dist_MeanBest
        Local_ub = Center + Dist_MeanBest

        # trim the extra boundaries
        Local_lb = np.where(Local_lb < lb, lb, Local_lb)
        Local_ub = np.where(Local_ub > ub, ub, Local_ub)

        # Reshape Local_lb and Local_ub to have the shape (Dim, 1)
        Local_ub = Local_ub.reshape((Dim, 1))
        Local_lb = Local_lb.reshape((Dim, 1))

        # generate the new population ( solution) inside the newly calculated search area
        PosLoc = np.random.rand(Dim, populationsize) * (Local_ub - Local_lb) + Local_lb

        # disperse the population to search around the potential optimum area, while slowly focusing on the center of the search area
        for i in range(populationsize):
            if np.random.rand() < EXP:
                Explore = PosLoc[:, i] - Best_Poses[:, i]
                Pos[:, i] = PosLoc[:, i] + Explore
            else:
                Exploite = PosLoc[:, i] - Center
                Pos[:, i] = PosLoc[:, i] + np.random.rand() * Exploite

        # put back particles that went outside the search field
        upid = Pos > ub
        upr = np.random.rand(*upid.nonzero()[0].shape)
        Pos[upid] = upr * (ub - lb) + lb

        downid = Pos < lb
        downr = np.random.rand(*downid.nonzero()[0].shape)
        Pos[downid] = downr * (ub - lb) + lb

        # evaluate and update the best points
        Fit = np.apply_along_axis(fobj, 0, Pos)
        for i in range(populationsize):
            if Fit[i] < Best_Fits[i]:
                Best_Fits[i] = Fit[i]
                Best_Poses[:, i] = Pos[:, i]

        # update the MeanBest and get the best fitness in this iteration
        MeanBest = np.mean(Best_Poses, axis=1)
        ind = np.argmin(Fit)
        It_BestFit = Fit[ind]
        It_BestPos = Pos[:, ind]
        Dist_MeanBest = Center - MeanBest


         # check if we found a new best solution and add the reference point and distances in that case
        if It_BestFit < Optimum_Fit:
            Optimum_Fit = It_BestFit
            Center = It_BestPos


        # Store the progress within each iteration
        run_fitness_progress.append(Optimum_Fit)
        run_center_progress.append(Center)
        # %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% End of the Algorithm %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        ## OPTIONAL: display the progress every 100 Its
        if It % 100 == 1:  # every 100 show the actual best fitness (not absolute best)
            print([It_BestFit, Center])


   # Store the progress for each run
    fitness_progress.append(run_fitness_progress)
    center_progress.append(run_center_progress)

    ## report results for every run
    print(f'Stopped in: {It} Its')
    print(f'Fit: {Optimum_Fit}')
    print(f'Sol: {Center}')


# Plot the progress of Optimum_Fit
plt.figure(figsize=(10, 5))
for i in range(Number_of_Runs):
    plt.plot(range(Max_iterations), fitness_progress[i], label=f'Run {i+1}')
plt.title('Progress of Optimum_Fit')
plt.xlabel('Iteration')
plt.ylabel('Optimum_Fit Value')
plt.legend()
plt.show()

# Plot the last position of Center as a scatter plot
plt.figure(figsize=(8, 8))
for i in range(Number_of_Runs):
    last_center = center_progress[i][-1]
    plt.scatter(last_center[0], last_center[1], label=f'Run {i+1}')

plt.title('Last Position of Center')
plt.xlabel('Dimension 1')
plt.ylabel('Dimension 2')

# Set axis limits
plt.xlim(-500, 500)
plt.ylim(-500, 500)

plt.legend(loc='lower left')
plt.show()

#This code implements YUKI algorithm to optimize the Schwefel function in 30 dimensions.  minimum of a given objective function.

#The algorithm executed for a total of 10 runs, each with a population size of 30 and a maximum of 200 iterations. The search space is defined by lower and upper bounds of -500 and 500, respectively, in 30 dimensions.

#The algorithm starts by initializing the population with random positions within the search space and evaluating their fitness using the Schwefel function. The best positions and their corresponding fitness values are recorded, and the algorithm iteratively updates the positions of the solutions based on their best positions found so far.

#During each iteration, the search space is narrowed around the best position found so far by calculating a local search area centered at the mean best position. A new population is then generated by dispersing the particles around the search area, while gradually focusing them towards the center of the search area.

#The algorithm then evaluates the fitness of the new population, updates the best positions and fitness values, and continues to the next iteration. The process is repeated until either the maximum number of iterations is reached or the algorithm converges to a satisfactory solution.

#Finally, the algorithm reports the best fitness value and the corresponding solution found in each run. It also prints the progress of the best fitness value every 10 iterations.
